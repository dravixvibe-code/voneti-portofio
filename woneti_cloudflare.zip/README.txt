WONETI — готовый статический сайт

В архиве index.html: фото, оформление и JavaScript встроены в этот файл.
Сборка, Node.js, npm и сервер приложений не нужны.

CLOUDFLARE PAGES
1. Открой https://dash.cloudflare.com/ и войди в аккаунт.
2. Workers & Pages → Create application → Pages → Use direct upload.
3. Введи имя проекта и нажми Create project.
4. Загрузи этот ZIP или папку с index.html.
5. Нажми Deploy site. Cloudflare выдаст адрес на pages.dev.

Документация: https://developers.cloudflare.com/pages/get-started/direct-upload/

Можно распаковать архив и открыть index.html в браузере для просмотра.
Музыка запускается кнопкой «Включить». Копирование ника требует HTTPS
или разрешения браузера. Фото встроено; интернет нужен только для
Telegram-ссылок и загрузки шрифта (без сети используется запасной шрифт).

Это отдельная копия сайта. Изменения сайта в ChatGPT автоматически
сюда не переносятся: для обновления нужно загрузить новый index.html.
